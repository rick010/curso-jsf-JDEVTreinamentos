package br.com.framework.implementacao.crud;

/**
 * Aramzena variaveis de data source
 * @author alex
 *
 */
public class VariavelConexaoUtil {

	public static final String JAVA_COMP_ENV_JDBC_DATA_SOURCE = "java:/comp/env/jdbc/datasouce";

}
