package br.com.repository.interfaces;

import org.springframework.stereotype.Repository;

@Repository
public interface RepositoryComissaoFuncionarioFilial {
}